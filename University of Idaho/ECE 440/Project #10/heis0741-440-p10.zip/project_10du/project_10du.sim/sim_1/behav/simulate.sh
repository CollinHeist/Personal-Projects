#!/bin/bash -f
xv_path="/opt/Xilinx/Vivado/2016.4"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim factorial_testbench_behav -key {Behavioral:sim_1:Functional:factorial_testbench} -tclbatch factorial_testbench.tcl -log simulate.log
